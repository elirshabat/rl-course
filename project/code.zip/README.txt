------------------------------
Names
------------------------------
Alon Ressler , 201547510, alonress@gmail.com  
Eliran Shabat, 201602877, shabat.eliran@gmail.com

------------------------------
Instructions
------------------------------
Simply run the script main.py from the folder that contains it.

------------------------------
Names
------------------------------
Alon Ressler , 201547510, alonress@gmail.com  
Eliran Shabat, 201602877, shabat.eliran@gmail.com

------------------------------
Instructions
------------------------------
Simply run the script main.py from the folder that contains it.

------------------------------
Parameter Changes
------------------------------
We changed the learning rate from 0.00025 to 0.0005.

